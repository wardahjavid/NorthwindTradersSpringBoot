package com.pluralsight.NorthwindTradersSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NorthwindTradersSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
